Gracias por descargar! 
Por favor, si compartes dame creditos.
No borres ni cambies la previa ni tampoco esta nota.

Disfruta el cursor! 

Mi DeviantArt: abrunettesdesire.deviantart.com