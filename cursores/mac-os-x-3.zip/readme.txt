﻿=== Mac OS X Cursor Set ===

By: lilDavid

Download: http://www.rw-designer.com/cursor-set/mac-os-x-3

Author's description:

Cursors used on Mac OS X

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.